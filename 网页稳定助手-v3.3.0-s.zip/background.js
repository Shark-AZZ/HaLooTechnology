const TEMU_US_URL = 'https://www.temu.com/?region=211&language=en&currency=USD';
const TEMU_COOKIE_URL = 'https://www.temu.com/';
const VERIFY_GUIDE_URL = 'https://raw.githubusercontent.com/Shark-AZZ/HaLooTechnology-License/refs/heads/main/%E9%AA%8C%E8%AF%81%E6%93%8D%E4%BD%9C.md';
const VERIFY_GUIDE_FALLBACK = '此模块将不定期联网更新，请保证已连接外网，验证处理，请循此方可解： 111 当正常采集，中途，打开商品详情页要求登录时，关闭所有temu页面，新开temu主页 222 未解决，优先清理并新开，新开后等待刷新，等待弹出验证请求窗口，验证后尝试操作 333 未解决，多次尝试清理后新开，仍未解决，更换节点，更换后清理并新开 444 未解决，检查win系统设置的地区确定为美国，时区为utc-6:00，中部时间（美国和加拿大），启用夏令时，浏览器默认语言/语言管理插件设置为美英，然后重启浏览器，多次重复清理并新开，尝试不同节点 555 节点优先考虑，猜测使用人数少的节点 666 以上无法解决时，请务必抱头痛哭/bushi，起立，双手举过头顶，大喊一声“兆臣！”，兆臣将5秒内到达战场 777 更多里支持局域网信息共享，测试阶段的程序将在此发布';
const VERIFY_GUIDE_TIMEOUT_MS = 6000;
const TEMU_HISTORY_MAX_RESULTS = 20000;
const TEMU_HOSTS = [
  'temu.com',
  'www.temu.com',
  'm.temu.com',
  'us.temu.com',
  'link.temu.com'
];
const TEMU_SITE_DATA_TYPES = {
  cache: true,
  cacheStorage: true,
  cookies: true,
  fileSystems: true,
  indexedDB: true,
  localStorage: true,
  serviceWorkers: true,
  webSQL: true
};
const reloadOnceTabs = new Set();
let historyCleanupTask = null;

// 判断地址是否属于Temu，由标签页、历史和刷新监听流程调用，下游只处理temu.com范围，异常地址直接跳过
function isTemuUrl(value) {
  try {
    const url = new URL(String(value || ''));
    const host = url.hostname.toLowerCase();
    return host === 'temu.com' || host.endsWith('.temu.com');
  } catch {
    return false;
  }
}

// 规范Temu主机名，由Cookie、标签页和历史域名收集调用，下游过滤非Temu域名，异常输入返回空文本
function normalizeTemuHost(value) {
  const host = String(value || '').trim().toLowerCase().replace(/^\.+/, '');
  if (host === 'temu.com' || host.endsWith('.temu.com')) return host;
  return '';
}

// 搜索Temu历史记录，由清理入口调用，下游补齐曾访问子域并异步删除历史，查询失败时返回空列表
async function findTemuHistoryItems() {
  try {
    const items = await chrome.history.search({
      text: 'temu.com',
      startTime: 0,
      maxResults: TEMU_HISTORY_MAX_RESULTS
    });
    return Array.isArray(items) ? items.filter((item) => isTemuUrl(item.url || '')) : [];
  } catch {
    return [];
  }
}

// 收集Temu Cookie，由清理入口调用，下游仅用于补齐Cookie出现过的子域，实际Cookie删除统一交给browsingData
async function collectTemuCookies() {
  try {
    const cookies = await chrome.cookies.getAll({ domain: 'temu.com' });
    return Array.isArray(cookies) ? cookies : [];
  } catch {
    return [];
  }
}

// 收集Temu相关主机名，由清理入口调用，下游合并固定入口、历史、Cookie和当前标签页，单项查询失败时继续固定范围
async function collectTemuHosts(historyItems, cookies) {
  const hosts = new Set(TEMU_HOSTS);
  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      const value = tab.url || tab.pendingUrl || '';
      if (!isTemuUrl(value)) continue;
      const host = normalizeTemuHost(new URL(value).hostname);
      if (host) hosts.add(host);
    }
  } catch {
  }
  for (const cookie of cookies || []) {
    const host = normalizeTemuHost(cookie.domain);
    if (host) hosts.add(host);
  }
  for (const item of historyItems || []) {
    try {
      const host = normalizeTemuHost(new URL(item.url || '').hostname);
      if (host) hosts.add(host);
    } catch {
    }
  }
  return [...hosts];
}

// 生成Temu候选Origin，由站点数据清理调用，下游同时覆盖HTTP和HTTPS，避免不同协议下遗留站点存储
function getTemuOrigins(hosts) {
  const origins = [];
  for (const host of hosts) {
    origins.push(`https://${host}`);
    origins.push(`http://${host}`);
  }
  return origins;
}

// 关闭当前Temu页面，由清理入口调用，下游一次性关闭全部Temu标签页，只有Temu页时先补一个空白页避免浏览器无页面
async function closeTemuTabs() {
  try {
    const tabs = await chrome.tabs.query({});
    const temuIds = tabs
      .filter((tab) => typeof tab.id === 'number' && isTemuUrl(tab.url || tab.pendingUrl || ''))
      .map((tab) => tab.id);
    if (!temuIds.length) return 0;
    const hasOtherTab = tabs.some((tab) => typeof tab.id === 'number' && !isTemuUrl(tab.url || tab.pendingUrl || ''));
    if (!hasOtherTab) await chrome.tabs.create({ url: 'about:blank', active: false });
    await chrome.tabs.remove(temuIds);
    return temuIds.length;
  } catch {
    return 0;
  }
}

// 删除已捕获的Temu历史，由清理入口后台调用，下游一次并发提交全部历史URL，不阻塞站点数据主清理流程
async function clearTemuHistory(historyItems) {
  const urls = [...new Set((historyItems || []).map((item) => item.url).filter((url) => url && isTemuUrl(url)))];
  if (!urls.length) return 0;
  const results = await Promise.allSettled(urls.map((url) => chrome.history.deleteUrl({ url })));
  return results.filter((result) => result.status === 'fulfilled').length;
}

// 清理Temu Cookie、缓存和站点存储，由清理入口调用，下游只调用一次browsingData.remove以缩短关键清理链
async function clearTemuSiteData(origins) {
  await chrome.browsingData.remove({ since: 0, origins }, TEMU_SITE_DATA_TYPES);
}

// 执行快速完整Temu清理，由面板清理按钮调用，下游并行收集历史和Cookie、关闭Temu页并一次清理站点数据，历史删除放后台完成
async function cleanTemu() {
  const [historyItems, cookies] = await Promise.all([
    findTemuHistoryItems(),
    collectTemuCookies()
  ]);
  const hosts = await collectTemuHosts(historyItems, cookies);
  const origins = getTemuOrigins(hosts);
  const closed = await closeTemuTabs();
  historyCleanupTask = clearTemuHistory(historyItems).catch(() => 0);
  await clearTemuSiteData(origins);
  return {
    ok: true,
    closed,
    historyQueued: historyItems.length,
    origins: origins.length
  };
}

// 写入Temu美国站偏好，由打开美国站流程调用，下游并发设置地区、语言和币种Cookie，单项失败不阻止页面打开
async function setTemuUsPreferences() {
  const items = [
    { name: 'region', value: '211' },
    { name: 'language', value: 'en' },
    { name: 'currency', value: 'USD' }
  ];
  const results = await Promise.allSettled(items.map((item) => chrome.cookies.set({
    url: TEMU_COOKIE_URL,
    name: item.name,
    value: item.value,
    domain: '.temu.com',
    path: '/',
    secure: true
  })));
  return results.filter((result) => result.status === 'rejected').length;
}

// 打开Temu美国站，由面板打开按钮调用，下游并发写入美国站偏好后新建页面并登记一次标准刷新
async function openTemuUsSite() {
  const preferenceFailed = await setTemuUsPreferences();
  const tab = await chrome.tabs.create({ url: TEMU_US_URL, active: true });
  if (typeof tab?.id === 'number') reloadOnceTabs.add(tab.id);
  return { ok: typeof tab?.id === 'number', preferenceFailed };
}

// 对插件新开的美国站执行一次标准刷新，由tabs更新监听调用，下游首次加载完成后移除标记再调用tabs.reload，防止刷新循环
async function reloadOpenedTemuTab(tabId, changeInfo, tab) {
  if (!reloadOnceTabs.has(tabId)) return;
  const value = tab?.url || tab?.pendingUrl || '';
  if (value && !isTemuUrl(value)) {
    reloadOnceTabs.delete(tabId);
    return;
  }
  if (changeInfo.status !== 'complete' || !isTemuUrl(value)) return;
  reloadOnceTabs.delete(tabId);
  try {
    await chrome.tabs.reload(tabId);
  } catch {
  }
}

// 获取远程验证说明，由面板初始化调用，下游读取GitHub Raw最新文本，超时或联网失败时返回内置说明
async function getVerifyGuide() {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), VERIFY_GUIDE_TIMEOUT_MS);
  try {
    const response = await fetch(`${VERIFY_GUIDE_URL}?t=${Date.now()}`, {
      cache: 'no-store',
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`http_${response.status}`);
    const content = String(await response.text()).replaceAll('\r\n', '\n').trim();
    if (!content) throw new Error('empty_guide');
    return { ok: true, content: content.slice(0, 20000) };
  } catch {
    return { ok: false, content: VERIFY_GUIDE_FALLBACK };
  } finally {
    clearTimeout(timer);
  }
}

// 分发面板消息，由runtime监听调用，下游仅提供清理、打开美国站和读取说明，未知消息返回失败
async function handleMessage(message) {
  if (message?.type === 'cleanTemu') return await cleanTemu();
  if (message?.type === 'openTemuUsSite') return await openTemuUsSite();
  if (message?.type === 'getVerifyGuide') return await getVerifyGuide();
  return { ok: false, error: 'unknown_message' };
}

// 注册消息监听，由Chrome后台启动调用，下游转发异步结果，异常统一返回失败状态防止面板永久等待
function registerMessageListener() {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleMessage(message, sender)
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: 'action_failed' }));
    return true;
  });
}

// 注册一次刷新监听，由Chrome后台启动调用，下游只处理插件新开的Temu标签页并在首次完成后刷新一次
function registerReloadListener() {
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    reloadOpenedTemuTab(tabId, changeInfo, tab);
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    reloadOnceTabs.delete(tabId);
  });
}

// 设置工具栏点击打开侧边栏，由安装和后台启动调用，下游启用侧边栏入口，失败时不影响清理和打开功能
async function enableSidePanel() {
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch {
  }
}

chrome.runtime.onInstalled.addListener(() => enableSidePanel());
chrome.runtime.onStartup.addListener(() => enableSidePanel());
registerMessageListener();
registerReloadListener();
enableSidePanel();
