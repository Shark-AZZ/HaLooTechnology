const cleanButton = document.getElementById('cleanTemu');
const openButton = document.getElementById('openTemu');
const statusBox = document.getElementById('status');
const guideContent = document.getElementById('guideContent');
let cleanStatusTimer = null;

// 更新清理按钮状态，由彻底清理流程调用，下游只锁定清理按钮并保留打开按钮独立可用
function setCleanBusy(message, busy) {
  statusBox.textContent = message;
  cleanButton.disabled = busy;
}

// 更新打开按钮状态，由打开美国站流程调用，下游只锁定打开按钮避免重复新建页面
function setOpenBusy(message, busy) {
  statusBox.textContent = message;
  openButton.disabled = busy;
}

// 启动清理进度提示，由清理按钮调用，下游按秒显示已运行时间，清理完成后由停止流程释放计时器
function startCleanProgress() {
  let seconds = 0;
  clearInterval(cleanStatusTimer);
  cleanStatusTimer = setInterval(() => {
    seconds += 1;
    statusBox.textContent = `正在清理 ${seconds}s`;
  }, 1000);
}

// 停止清理进度提示，由清理结束流程调用，下游释放计时器避免面板继续更新状态
function stopCleanProgress() {
  clearInterval(cleanStatusTimer);
  cleanStatusTimer = null;
}

// 静默刷新验证说明，由清理和打开按钮调用，下游重新读取GitHub Raw最新文本并更新当前说明，失败时保持现有内容
async function refreshVerifyGuideSilently() {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'getVerifyGuide' });
    if (result?.ok && result?.content) guideContent.textContent = result.content;
  } catch {
  }
}

// 执行Temu清理，由清理按钮调用，下游先静默刷新验证说明，再请求后台一次清理Cookie、缓存和站点存储并后台删除历史，异常时直接提示失败
async function cleanTemu() {
  void refreshVerifyGuideSilently();
  setCleanBusy('正在清理', true);
  startCleanProgress();
  try {
    const result = await chrome.runtime.sendMessage({ type: 'cleanTemu' });
    statusBox.textContent = result?.ok ? '清理完成' : '清理失败';
  } catch {
    statusBox.textContent = '清理失败';
  } finally {
    stopCleanProgress();
    cleanButton.disabled = false;
  }
}

// 打开Temu美国站，由打开按钮调用，下游先静默刷新验证说明，再请求后台写入美国站偏好、新建页面并在首次加载完成后标准刷新一次
async function openTemuUsSite() {
  void refreshVerifyGuideSilently();
  setOpenBusy('正在打开', true);
  try {
    const result = await chrome.runtime.sendMessage({ type: 'openTemuUsSite' });
    statusBox.textContent = result?.ok ? '已打开美国站' : '打开失败';
  } catch {
    statusBox.textContent = '打开失败';
  } finally {
    openButton.disabled = false;
  }
}

// 加载验证操作说明，由面板初始化调用，下游读取GitHub Raw最新文本并直接展示，联网失败时使用后台内置说明
async function loadVerifyGuide() {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'getVerifyGuide' });
    guideContent.textContent = result?.content || '暂无说明';
  } catch {
    guideContent.textContent = '说明获取失败';
  }
}

cleanButton.addEventListener('click', () => cleanTemu());
openButton.addEventListener('click', () => openTemuUsSite());
loadVerifyGuide();
